package com.example.adblock

import android.content.Context
import java.io.File

/** Набор доменов рекламных сетей. Блокируется домен и все его поддомены. */
class Blocklist private constructor(private val domains: Set<String>) {

    val size: Int get() = domains.size

    fun isBlocked(name: String): Boolean {
        val labels = name.lowercase().trimEnd('.').split('.')
        for (i in labels.indices) {
            if (labels.subList(i, labels.size).joinToString(".") in domains) return true
        }
        return false
    }

    companion object {
        const val EXTRA_FILE = "blocklist_extra.txt"

        private val DOMAIN = Regex("^[a-z0-9_.-]+\\.[a-z0-9-]{2,}$")
        private val WS = Regex("\\s+")

        /** Загружает встроенный список + скачанные списки (если есть). */
        fun load(context: Context): Blocklist {
            val set = HashSet<String>(300_000)
            context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                for (l in lines) parseLine(l)?.let { set.add(it) }
            }
            val extra = File(context.filesDir, EXTRA_FILE)
            if (extra.exists()) {
                extra.bufferedReader().useLines { lines ->
                    for (l in lines) parseLine(l)?.let { set.add(it) }
                }
            }
            return Blocklist(set)
        }

        /**
         * Понимает три формата: просто домен, hosts ("0.0.0.0 domain")
         * и AdGuard ("||domain^"). Всё остальное игнорируется.
         */
        fun parseLine(raw: String): String? {
            var line = raw.trim().lowercase()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("!") || line.startsWith("@@")) {
                return null
            }
            line = line.substringBefore('#').trim()

            val candidate: String = when {
                line.startsWith("||") -> {
                    if (!line.endsWith("^") || line.contains('$') || line.contains('/') || line.contains('*')) {
                        return null
                    }
                    line.substring(2, line.length - 1)
                }
                else -> {
                    val parts = line.split(WS)
                    when {
                        parts.size == 1 -> parts[0]
                        parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                        else -> return null
                    }
                }
            }
            val d = candidate.removePrefix("*.").trimEnd('.')
            if (d == "localhost" || d.endsWith(".localdomain") || !DOMAIN.matches(d)) return null
            if (d.last().isDigit()) return null // IP-адрес, а не домен
            return d
        }
    }
}
