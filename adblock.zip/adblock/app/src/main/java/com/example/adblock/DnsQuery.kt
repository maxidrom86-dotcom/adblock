package com.example.adblock

/** Разбор DNS-запроса из IPv4/UDP пакета и сборка ответа обратно в IP-пакет. */
class DnsQuery private constructor(
    private val raw: ByteArray,
    private val ihl: Int,
    val name: String,
    private val dnsOffset: Int,
    private val questionEnd: Int
) {

    /** DNS-часть запроса (без IP/UDP заголовков), для пересылки upstream-серверу. */
    fun dnsPayload(): ByteArray = raw.copyOfRange(dnsOffset, raw.size)

    /** Ответ NXDOMAIN: домен «не существует», приложение рекламу не загрузит. */
    fun nxdomainPayload(): ByteArray {
        val p = raw.copyOfRange(dnsOffset, questionEnd)
        p[2] = (0x80 or (p[2].toInt() and 0x01)).toByte() // QR=1, RD копируем
        p[3] = 0x83.toByte()                               // RA=1, RCODE=3
        for (i in 6..11) p[i] = 0                          // ANCOUNT/NSCOUNT/ARCOUNT = 0
        return p
    }

    /** Оборачивает DNS-ответ в IPv4/UDP пакет, который уходит обратно в tun. */
    fun buildReply(payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val out = ByteArray(total)
        out[0] = 0x45
        out[2] = (total shr 8).toByte()
        out[3] = total.toByte()
        out[6] = 0x40 // DF
        out[8] = 64   // TTL
        out[9] = 17   // UDP
        System.arraycopy(raw, 16, out, 12, 4) // src = бывший dst
        System.arraycopy(raw, 12, out, 16, 4) // dst = бывший src
        val c = checksum(out, 0, 20)
        out[10] = (c shr 8).toByte()
        out[11] = c.toByte()

        System.arraycopy(raw, ihl + 2, out, 20, 2) // src port = бывший dst port
        System.arraycopy(raw, ihl, out, 22, 2)     // dst port = бывший src port
        val udpLen = 8 + payload.size
        out[24] = (udpLen shr 8).toByte()
        out[25] = udpLen.toByte()
        // UDP checksum = 0 допустим для IPv4
        System.arraycopy(payload, 0, out, 28, payload.size)
        return out
    }

    companion object {
        fun parse(raw: ByteArray): DnsQuery? {
            if (raw.size < 20) return null
            if ((raw[0].toInt() shr 4) != 4) return null
            val ihl = (raw[0].toInt() and 0x0F) * 4
            if (ihl < 20 || raw[9].toInt() != 17 || raw.size < ihl + 8 + 12) return null
            val dstPort = ((raw[ihl + 2].toInt() and 0xFF) shl 8) or (raw[ihl + 3].toInt() and 0xFF)
            if (dstPort != 53) return null

            val dns = ihl + 8
            if ((raw[dns + 2].toInt() and 0x80) != 0) return null // это ответ, не запрос
            val qd = ((raw[dns + 4].toInt() and 0xFF) shl 8) or (raw[dns + 5].toInt() and 0xFF)
            if (qd != 1) return null

            var pos = dns + 12
            val sb = StringBuilder()
            while (true) {
                if (pos >= raw.size) return null
                val len = raw[pos].toInt() and 0xFF
                if (len == 0) { pos++; break }
                if ((len and 0xC0) != 0) return null
                if (pos + 1 + len > raw.size) return null
                if (sb.isNotEmpty()) sb.append('.')
                sb.append(String(raw, pos + 1, len, Charsets.US_ASCII))
                pos += 1 + len
            }
            if (pos + 4 > raw.size) return null
            return DnsQuery(raw, ihl, sb.toString().lowercase(), dns, pos + 4)
        }

        private fun checksum(b: ByteArray, off: Int, len: Int): Int {
            var sum = 0
            var i = off
            while (i < off + len) {
                sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
                i += 2
            }
            while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
            return sum.inv() and 0xFFFF
        }
    }
}
