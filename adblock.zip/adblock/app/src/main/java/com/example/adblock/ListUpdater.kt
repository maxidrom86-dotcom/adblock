package com.example.adblock

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Скачивает публичные списки рекламных доменов прямо на телефоне и кладёт в filesDir. */
object ListUpdater {

    val SOURCES = listOf(
        "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/domains/light.txt",
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt"
    )

    /** Работает в фоновом потоке; onDone вызывается из него же. */
    fun update(context: Context, onDone: (Result<Int>) -> Unit) {
        val app = context.applicationContext
        Thread({
            try {
                val domains = LinkedHashSet<String>()
                var okSources = 0
                for (url in SOURCES) {
                    try {
                        val c = URL(url).openConnection() as HttpURLConnection
                        c.connectTimeout = 15_000
                        c.readTimeout = 30_000
                        c.inputStream.bufferedReader().useLines { lines ->
                            for (l in lines) Blocklist.parseLine(l)?.let { domains.add(it) }
                        }
                        c.disconnect()
                        okSources++
                    } catch (e: Exception) {
                        // один источник недоступен — берём остальные
                    }
                }
                if (okSources == 0) throw IOException("Не удалось скачать ни один список")

                val tmp = File(app.filesDir, Blocklist.EXTRA_FILE + ".tmp")
                tmp.bufferedWriter().use { w -> for (d in domains) { w.write(d); w.newLine() } }
                tmp.renameTo(File(app.filesDir, Blocklist.EXTRA_FILE))

                app.getSharedPreferences("adblock", Context.MODE_PRIVATE)
                    .edit().putInt("extra_domains", domains.size).apply()
                AdBlockVpnService.reload(app)
                onDone(Result.success(domains.size))
            } catch (e: Exception) {
                onDone(Result.failure(e))
            }
        }, "adblock-update").start()
    }
}
