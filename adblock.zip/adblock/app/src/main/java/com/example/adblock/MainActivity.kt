package com.example.adblock

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var listInfo: TextView
    private lateinit var toggle: Button
    private lateinit var update: Button
    @Volatile private var updating = false

    private val refresh = object : Runnable {
        override fun run() {
            val on = AdBlockVpnService.isRunning
            status.text = if (on) "Защита включена" else "Защита выключена"
            toggle.text = if (on) "Выключить" else "Включить"
            stats.text = "Заблокировано запросов: ${AdBlockVpnService.blockedCount.get()}\n" +
                "Пропущено запросов: ${AdBlockVpnService.allowedCount.get()}"
            val extra = getSharedPreferences("adblock", Context.MODE_PRIVATE).getInt("extra_domains", 0)
            listInfo.text = if (updating) "Обновляю списки…"
            else if (extra > 0) "Скачанные списки: $extra доменов"
            else "Скачанные списки: нет (работает только встроенный список)"
            update.isEnabled = !updating
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 24f; gravity = Gravity.CENTER }
        stats = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(0, pad, 0, pad) }
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        listInfo = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setPadding(0, pad, 0, 0) }
        update = Button(this).apply {
            text = "Обновить списки"
            setOnClickListener { updateLists() }
        }
        val note = TextView(this).apply {
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, 0)
            text = "Блокирует рекламные домены на уровне DNS. Реклама, которая приходит " +
                "с тех же серверов, что и контент (YouTube, соцсети), не блокируется. " +
                "Отключите «Частный DNS» в настройках сети, иначе он обходит фильтр."
        }
        root.addView(status)
        root.addView(stats)
        root.addView(toggle)
        root.addView(listInfo)
        root.addView(update)
        root.addView(note)
        setContentView(root)

        // Первый запуск: скачиваем большие списки автоматически.
        if (!File(filesDir, Blocklist.EXTRA_FILE).exists()) updateLists()
    }

    private fun updateLists() {
        if (updating) return
        updating = true
        ListUpdater.update(this) { updating = false }
    }

    private fun onToggle() {
        if (AdBlockVpnService.isRunning) {
            startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare != null) startActivityForResult(prepare, 1) else startVpn()
    }

    private fun startVpn() {
        startService(Intent(this, AdBlockVpnService::class.java))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) startVpn()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }
}
