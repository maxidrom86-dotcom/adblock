package com.example.adblock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

/** Поднимает защиту после перезагрузки, если пользователь оставлял её включённой. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val enabled = context.getSharedPreferences("adblock", Context.MODE_PRIVATE)
            .getBoolean("enabled", false)
        if (!enabled || VpnService.prepare(context) != null) return
        try {
            context.startService(Intent(context, AdBlockVpnService::class.java))
        } catch (e: Exception) {
        }
    }
}
