package com.example.adblock

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/**
 * Локальный VPN, в который заворачивается ТОЛЬКО DNS-трафик (маршрут на один фиктивный адрес).
 * Запросы к рекламным доменам получают NXDOMAIN, остальные пересылаются на реальный DNS.
 * Трафик приложений через VPN не идёт, наружу уходят только DNS-запросы.
 */
class AdBlockVpnService : VpnService() {

    companion object {
        const val ACTION_STOP = "com.example.adblock.STOP"
        @Volatile var isRunning = false
        val blockedCount = AtomicLong(0)
        val allowedCount = AtomicLong(0)

        private const val VPN_ADDRESS = "10.111.222.1"
        private const val FAKE_DNS = "10.111.222.2"
        private const val UPSTREAM_DNS = "1.1.1.1"

        /** Текущий список; подменяется на лету после обновления списков. */
        @Volatile var blocklist: Blocklist? = null

        fun reload(context: Context) {
            blocklist = Blocklist.load(context.applicationContext)
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var pool: ExecutorService? = null

    private fun setEnabledFlag(value: Boolean) {
        getSharedPreferences("adblock", MODE_PRIVATE).edit().putBoolean("enabled", value).apply()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            setEnabledFlag(false)
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (isRunning) return
        if (blocklist == null) blocklist = Blocklist.load(this)
        setEnabledFlag(true)
        var established: ParcelFileDescriptor? = null
        try {
            established = Builder()
                .setSession("AdBlock")
                .setMtu(1500)
                .addAddress(VPN_ADDRESS, 32)
                .addDnsServer(FAKE_DNS)
                .addRoute(FAKE_DNS, 32)
                .establish()
        } catch (e: Exception) {
            established = null
        }
        val fd = established ?: return

        tun = fd
        pool = Executors.newFixedThreadPool(8)
        isRunning = true
        worker = Thread({ runLoop(fd) }, "adblock-loop").also { it.start() }
    }

    private fun runLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (isRunning) {
                val n = input.read(buf)
                if (n <= 0) {
                    Thread.sleep(5)
                    continue
                }
                val q = DnsQuery.parse(buf.copyOf(n)) ?: continue
                if (blocklist?.isBlocked(q.name) == true) {
                    blockedCount.incrementAndGet()
                    QueryLog.add(q.name, true)
                    writeTun(output, q.buildReply(q.nxdomainPayload()))
                } else {
                    allowedCount.incrementAndGet()
                    QueryLog.add(q.name, false)
                    pool?.execute { forward(q, output) }
                }
            }
        } catch (e: IOException) {
        } catch (e: InterruptedException) {
        }
    }

    private fun forward(q: DnsQuery, output: FileOutputStream) {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            if (!protect(socket)) return // чтобы запрос не зациклился обратно в VPN
            socket.soTimeout = 4000
            val payload = q.dnsPayload()
            socket.send(DatagramPacket(payload, payload.size, InetAddress.getByName(UPSTREAM_DNS), 53))
            val resp = ByteArray(4096)
            val packet = DatagramPacket(resp, resp.size)
            socket.receive(packet)
            writeTun(output, q.buildReply(resp.copyOf(packet.length)))
        } catch (e: Exception) {
        } finally {
            socket?.close()
        }
    }

    private fun writeTun(output: FileOutputStream, packet: ByteArray) {
        synchronized(output) {
            try {
                output.write(packet)
            } catch (e: IOException) {
            }
        }
    }

    private fun stopVpn() {
        isRunning = false
        worker?.interrupt()
        pool?.shutdownNow()
        try {
            tun?.close()
        } catch (e: IOException) {
        }
        tun = null
        worker = null
        pool = null
    }

    override fun onRevoke() {
        setEnabledFlag(false)
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
