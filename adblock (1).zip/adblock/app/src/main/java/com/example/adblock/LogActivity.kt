package com.example.adblock

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class LogActivity : Activity() {

    private lateinit var list: ListView
    private var entries: List<Pair<String, Boolean>> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val hint = TextView(this).apply {
            textSize = 14f
            text = "Сначала поиграйте, пока реклама не появится, потом откройте этот список. " +
                "Нажмите на домен рекламы (обычно в названии есть ads, adserver, banner, " +
                "track, appsflyer и т.п.), чтобы заблокировать его."
        }
        val refresh = Button(this).apply {
            text = "Обновить"
            setOnClickListener { reload() }
        }
        list = ListView(this)
        list.setOnItemClickListener { _, _, position, _ -> onPick(entries[position]) }

        root.addView(hint)
        root.addView(refresh)
        root.addView(
            list,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
        reload()
    }

    private fun reload() {
        entries = QueryLog.snapshot()
        val lines = entries.map { if (it.second) "[заблокирован] ${it.first}" else it.first }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, lines)
    }

    private fun onPick(entry: Pair<String, Boolean>) {
        val domain = entry.first
        if (entry.second) {
            Toast.makeText(this, "Уже заблокирован", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Заблокировать?")
            .setMessage("$domain и все его поддомены")
            .setPositiveButton("Да") { _, _ ->
                val ok = Blocklist.addUserDomain(this, domain)
                Toast.makeText(
                    this,
                    if (ok) "Добавлено в блокировку" else "Не удалось добавить",
                    Toast.LENGTH_SHORT
                ).show()
                reload()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
