package com.example.adblock

/** Последние DNS-запросы (домен и был ли он заблокирован), новые сверху. */
object QueryLog {
    private const val MAX = 400
    private val map = LinkedHashMap<String, Boolean>()

    @Synchronized
    fun add(name: String, blocked: Boolean) {
        map.remove(name)
        map[name] = blocked
        while (map.size > MAX) {
            val it = map.entries.iterator()
            it.next()
            it.remove()
        }
    }

    @Synchronized
    fun snapshot(): List<Pair<String, Boolean>> =
        map.entries.map { Pair(it.key, it.value) }.reversed()
}
